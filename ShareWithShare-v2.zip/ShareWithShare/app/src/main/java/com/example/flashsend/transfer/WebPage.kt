/*
 * STEP 5: Phone-to-PC web page. Package: com.example.flashsend.transfer
 * Served by SenderServer at /web?t=TOKEN. A PC browser can download the shared
 * files and upload files to the phone (saved to Downloads/ShareWithShare).
 */
package com.example.flashsend.transfer

import java.net.NetworkInterface

object WebPage {
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;")
        .replace(">", "&gt;").replace("\"", "&quot;")

    private fun fmt(b: Long): String = when {
        b >= 1L shl 30 -> "%.2f GB".format(b / (1024.0 * 1024 * 1024))
        b >= 1L shl 20 -> "%.1f MB".format(b / (1024.0 * 1024))
        b >= 1L shl 10 -> "%.0f KB".format(b / 1024.0)
        else -> "$b B"
    }

    fun render(files: List<SharedFile>, token: String): String {
        val rows = if (files.isEmpty()) "<li>No files shared from the phone.</li>" else
            files.joinToString("") {
                "<li><a href=\"/dl/${it.id}?t=$token\">${esc(it.name)}</a> <span>${fmt(it.size)}</span></li>"
            }
        return """<!doctype html>
<html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Share with Share</title>
<style>
:root{--bg:#fff;--fg:#1a1a1a;--card:#f3f4f6;--acc:#2563eb}
@media(prefers-color-scheme:dark){:root{--bg:#111;--fg:#eee;--card:#1f2125;--acc:#60a5fa}}
body{font-family:system-ui,sans-serif;background:var(--bg);color:var(--fg);max-width:640px;margin:0 auto;padding:24px}
h1{margin-top:0}h2{font-size:1.1rem;margin-top:32px}
ul{list-style:none;padding:0}li{background:var(--card);border-radius:8px;padding:12px;margin:8px 0;display:flex;justify-content:space-between;gap:12px}
a{color:var(--acc);word-break:break-all}span{opacity:.7;white-space:nowrap}
#drop{border:2px dashed var(--acc);border-radius:12px;padding:32px;text-align:center;cursor:pointer}
#drop.over{background:var(--card)}
</style></head><body>
<h1>Share with Share</h1>
<h2>Download from phone</h2>
<ul>$rows</ul>
<h2>Send to phone</h2>
<div id="drop">Drop files here or click to choose</div>
<input id="pick" type="file" multiple hidden>
<p id="st"></p>
<script>
var T="$token",st=document.getElementById('st'),drop=document.getElementById('drop'),pick=document.getElementById('pick');
drop.onclick=function(){pick.click()};
pick.onchange=function(){up(pick.files)};
drop.ondragover=function(e){e.preventDefault();drop.className='over'};
drop.ondragleave=function(){drop.className=''};
drop.ondrop=function(e){e.preventDefault();drop.className='';up(e.dataTransfer.files)};
function up(files){
  var i=0;
  (function next(){
    if(i>=files.length){st.textContent='All files sent to phone.';return;}
    var f=files[i],x=new XMLHttpRequest();
    x.open('POST','/web/upload?t='+T);
    x.upload.onprogress=function(e){if(e.lengthComputable)st.textContent=f.name+'  '+Math.round(e.loaded*100/e.total)+'%  ('+(i+1)+'/'+files.length+')';};
    x.onload=function(){if(x.status!==200){st.textContent='Failed: '+f.name;return;}i++;next();};
    x.onerror=function(){st.textContent='Failed: '+f.name;};
    var fd=new FormData();fd.append('file',f,f.name);x.send(fd);
  })();
}
</script></body></html>"""
    }
}

/** Finds the phone's own IPv4 address on the hotspot/Wi-Fi interface (not mobile data). */
fun localIp(): String {
    val candidates = NetworkInterface.getNetworkInterfaces()?.toList().orEmpty()
        .filter { it.isUp && !it.isLoopback && !it.name.startsWith("rmnet") && !it.name.startsWith("tun") }
        .flatMap { nif -> nif.inetAddresses.toList().filter { !it.isLoopbackAddress && it.isSiteLocalAddress && it.hostAddress?.contains(':') == false }
            .map { nif.name to it.hostAddress!! } }
    return (candidates.firstOrNull { it.first.startsWith("ap") || it.first.startsWith("swlan") || it.second.startsWith("192.168.43.") }
        ?: candidates.firstOrNull())?.second ?: "192.168.43.1"
}
