/*
 * STEP 7a: Foreground service so transfers survive screen-off / app switching.
 * Package: com.example.flashsend.service
 *
 * AndroidManifest.xml additions (permissions above <application>):
 *   <uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
 *   <uses-permission android:name="android.permission.FOREGROUND_SERVICE_DATA_SYNC"/>
 *   <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
 *   <uses-permission android:name="android.permission.WAKE_LOCK"/>
 * Inside <application>:
 *   <service android:name=".service.TransferService"
 *            android:exported="false"
 *            android:foregroundServiceType="dataSync"/>
 */
package com.example.flashsend.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.wifi.WifiManager
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

class TransferService : Service() {
    private var wakeLock: PowerManager.WakeLock? = null
    private var wifiLock: WifiManager.WifiLock? = null

    companion object {
        private const val CHANNEL = "transfer"
        private const val ID = 1

        fun start(ctx: Context, text: String) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, TransferService::class.java).putExtra("text", text)
            )
        }

        /** Updates the notification text (e.g. "photo.jpg 45%  22 MB/s"). */
        fun update(ctx: Context, text: String) {
            val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.notify(ID, build(ctx, text))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, TransferService::class.java))
        }

        private fun build(ctx: Context, text: String): Notification =
            NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.stat_sys_download)
                .setContentTitle("Share with Share")
                .setContentText(text)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Transfers", NotificationManager.IMPORTANCE_LOW)
        )
        ServiceCompat.startForeground(
            this, ID, build(this, intent?.getStringExtra("text") ?: "Working..."),
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        )

        if (wakeLock == null) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "flashsend:transfer")
                .apply { acquire(2 * 60 * 60 * 1000L) } // safety timeout: 2 hours
            val wm = applicationContext.getSystemService(WIFI_SERVICE) as WifiManager
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_LOW_LATENCY, "flashsend:wifi")
                .apply { acquire() }
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        wakeLock?.takeIf { it.isHeld }?.release()
        wifiLock?.takeIf { it.isHeld }?.release()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
