/*
 * STEP 4: Transfer engine. Package: com.example.flashsend.transfer
 *
 * build.gradle (app) dependencies to ADD:
 *   implementation("org.nanohttpd:nanohttpd:2.3.1")
 *   implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
 *
 * AndroidManifest.xml additions:
 *   <uses-permission android:name="android.permission.INTERNET"/>
 *   and on the <application ...> tag:  android:usesCleartextTraffic="true"
 */
package com.example.flashsend.transfer

import android.content.Context
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.*
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong

data class SharedFile(val id: Int, val name: String, val size: Long, val uri: Uri)
data class RemoteFile(val id: Int, val name: String, val size: Long)
data class Progress(val fileName: String, val done: Long, val total: Long, val bytesPerSec: Long)

/** Turn a picked Uri into a SharedFile (name + size). */
fun describe(ctx: Context, uri: Uri, id: Int): SharedFile {
    var name = "file_$id"
    var size = 0L
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            val s = c.getColumnIndex(OpenableColumns.SIZE)
            if (n >= 0) name = c.getString(n)
            if (s >= 0) size = c.getLong(s)
        }
    }
    return SharedFile(id, name, size, uri)
}

// ---------------------------------------------------------------------------
// SENDER: tiny HTTP server. /list returns files, /file/{id} streams with Range.
// ---------------------------------------------------------------------------
class SenderServer(
    private val ctx: Context,
    port: Int,
    private val token: String,
    private val files: List<SharedFile>
) : NanoHTTPD(port) {

    override fun serve(session: IHTTPSession): Response {
        val p0 = session.uri
        if (p0 == "/web" || p0.startsWith("/web/") || p0.startsWith("/dl/")) return handleWeb(session)
        if (session.headers["x-token"] != token)
            return newFixedLengthResponse(Response.Status.FORBIDDEN, MIME_PLAINTEXT, "Forbidden")

        val path = session.uri
        return when {
            path == "/list" -> {
                val arr = JSONArray()
                files.forEach {
                    arr.put(JSONObject().put("id", it.id).put("name", it.name).put("size", it.size))
                }
                newFixedLengthResponse(Response.Status.OK, "application/json", arr.toString())
            }
            path.startsWith("/file/") -> serveFile(session, path.removePrefix("/file/").toIntOrNull())
            else -> newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
        }
    }

    private fun serveFile(session: IHTTPSession, id: Int?, attachment: Boolean = false): Response {
        val f = files.firstOrNull { it.id == id }
            ?: return newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "No such file")

        var start = 0L
        var end = f.size - 1
        val rangeHeader = session.headers["range"]
        val m = rangeHeader?.let { Regex("bytes=(\\d+)-(\\d*)").matchEntire(it.trim()) }
        if (m != null) {
            start = m.groupValues[1].toLong()
            if (m.groupValues[2].isNotEmpty()) end = minOf(m.groupValues[2].toLong(), f.size - 1)
        }
        if (start > end && f.size > 0)
            return newFixedLengthResponse(Response.Status.RANGE_NOT_SATISFIABLE, MIME_PLAINTEXT, "")

        val pfd = ctx.contentResolver.openFileDescriptor(f.uri, "r")
            ?: return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Cannot open")
        val fis = FileInputStream(pfd.fileDescriptor)
        fis.channel.position(start)
        val length = end - start + 1

        val status = if (m != null) Response.Status.PARTIAL_CONTENT else Response.Status.OK
        val res = newFixedLengthResponse(status, "application/octet-stream", RangeStream(fis, pfd, length), length)
        res.addHeader("Accept-Ranges", "bytes")
        if (attachment) {
            val enc = URLEncoder.encode(f.name, "UTF-8").replace("+", "%20")
            res.addHeader("Content-Disposition", "attachment; filename*=UTF-8''$enc")
        }
        if (m != null) res.addHeader("Content-Range", "bytes $start-$end/${f.size}")
        return res
    }

    // ----- Phone-to-PC web mode (token is passed as ?t=... because browsers can't send headers) -----
    private fun handleWeb(session: IHTTPSession): Response {
        if (session.parameters["t"]?.firstOrNull() != token)
            return newFixedLengthResponse(Response.Status.FORBIDDEN, MIME_PLAINTEXT, "Forbidden")
        val path = session.uri
        return when {
            path == "/web" ->
                newFixedLengthResponse(Response.Status.OK, "text/html", WebPage.render(files, token))
            path.startsWith("/dl/") ->
                serveFile(session, path.removePrefix("/dl/").toIntOrNull(), attachment = true)
            path == "/web/upload" && session.method == NanoHTTPD.Method.POST -> handleUpload(session)
            else -> newFixedLengthResponse(Response.Status.NOT_FOUND, MIME_PLAINTEXT, "Not found")
        }
    }

    /** One file per request (the web page sends them one by one). Max ~2 GB per file. */
    private fun handleUpload(session: IHTTPSession): Response {
        val tmp = HashMap<String, String>()
        try {
            session.parseBody(tmp)
        } catch (e: Exception) {
            return newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Upload failed")
        }
        val tmpPath = tmp["file"]
            ?: return newFixedLengthResponse(Response.Status.BAD_REQUEST, MIME_PLAINTEXT, "No file")
        val name = (session.parameters["file"]?.firstOrNull() ?: "upload")
            .replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val dir = File(ctx.cacheDir, "uploads/${System.nanoTime()}").apply { mkdirs() }
        val dst = File(dir, name)
        val src = File(tmpPath)
        if (!src.renameTo(dst)) { src.copyTo(dst, overwrite = true); src.delete() }
        val ok = saveToDownloads(ctx, dst)
        dir.deleteRecursively()
        return if (ok) newFixedLengthResponse(Response.Status.OK, MIME_PLAINTEXT, "ok")
        else newFixedLengthResponse(Response.Status.INTERNAL_ERROR, MIME_PLAINTEXT, "Save failed")
    }

    /** Reads exactly `remaining` bytes, then closes the file descriptor. */
    private class RangeStream(
        private val fis: FileInputStream,
        private val pfd: ParcelFileDescriptor,
        private var remaining: Long
    ) : InputStream() {
        override fun read(): Int {
            if (remaining <= 0) return -1
            val b = fis.read()
            if (b >= 0) remaining--
            return b
        }

        override fun read(b: ByteArray, off: Int, len: Int): Int {
            if (remaining <= 0) return -1
            val n = fis.read(b, off, minOf(len.toLong(), remaining).toInt())
            if (n > 0) remaining -= n
            return n
        }

        override fun close() {
            runCatching { fis.close() }
            runCatching { pfd.close() }
        }
    }
}

// ---------------------------------------------------------------------------
// RECEIVER: parallel 4 MB chunks, resumable (finished chunks are remembered).
// ---------------------------------------------------------------------------
class Receiver(
    private val ctx: Context,
    private val host: String,
    private val port: Int,
    private val token: String
) {
    companion object {
        const val CHUNK = 4L * 1024 * 1024
        const val WORKERS = 4
        const val RETRIES = 3
    }

    private fun open(path: String, range: String? = null): HttpURLConnection =
        (URL("http://$host:$port$path").openConnection() as HttpURLConnection).apply {
            setRequestProperty("X-Token", token)
            range?.let { setRequestProperty("Range", it) }
            connectTimeout = 8000
            readTimeout = 15000
        }

    suspend fun list(): List<RemoteFile> = withContext(Dispatchers.IO) {
        val c = open("/list")
        try {
            if (c.responseCode != 200) throw IOException("Server refused (${c.responseCode})")
            val arr = JSONArray(c.inputStream.bufferedReader().readText())
            (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                RemoteFile(o.getInt("id"), o.getString("name"), o.getLong("size"))
            }
        } finally {
            c.disconnect()
        }
    }

    /** Files land in Android/data/<app>/files/received (no storage permission needed). */
    suspend fun download(file: RemoteFile, onProgress: (Progress) -> Unit): File = coroutineScope {
        val dir = ctx.getExternalFilesDir("received")!!.apply { mkdirs() }
        val safe = file.name.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val dest = File(dir, safe)
        val part = File(dir, "$safe.part")
        val meta = File(dir, "$safe.done")

        val chunks = ((file.size + CHUNK - 1) / CHUNK).toInt()
        val done = BooleanArray(chunks)
        if (part.exists() && meta.exists()) {
            meta.readLines().mapNotNull { it.toIntOrNull() }.filter { it in 0 until chunks }
                .forEach { done[it] = true }
        } else {
            meta.delete()
            RandomAccessFile(part, "rw").use { it.setLength(file.size) }
        }

        val doneBytes = AtomicLong(0)
        for (i in 0 until chunks) if (done[i]) {
            doneBytes.addAndGet(minOf(CHUNK, file.size - i * CHUNK))
        }
        val next = AtomicInteger(0)

        val ticker = launch(Dispatchers.Default) {
            var lastBytes = doneBytes.get()
            var lastTime = System.nanoTime()
            while (true) {
                delay(250)
                val nowBytes = doneBytes.get()
                val now = System.nanoTime()
                val speed = ((nowBytes - lastBytes) * 1_000_000_000L) / maxOf(1L, now - lastTime)
                lastBytes = nowBytes
                lastTime = now
                onProgress(Progress(file.name, nowBytes, file.size, speed))
            }
        }

        try {
            (1..WORKERS).map {
                async(Dispatchers.IO) {
                    RandomAccessFile(part, "rw").use { raf ->
                        val buf = ByteArray(256 * 1024)
                        while (true) {
                            val i = next.getAndIncrement()
                            if (i >= chunks) break
                            if (done[i]) continue
                            fetchChunk(file, i, raf, buf, doneBytes)
                            synchronized(meta) { meta.appendText("$i\n") }
                        }
                    }
                }
            }.awaitAll()
        } finally {
            ticker.cancel()
        }

        onProgress(Progress(file.name, file.size, file.size, 0))
        if (dest.exists()) dest.delete()
        part.renameTo(dest)
        meta.delete()
        dest
    }

    private fun fetchChunk(
        file: RemoteFile, index: Int, raf: RandomAccessFile, buf: ByteArray, counter: AtomicLong
    ) {
        val start = index * CHUNK
        val end = minOf(start + CHUNK, file.size) - 1
        var attempt = 0
        while (true) {
            var got = 0L
            try {
                val c = open("/file/${file.id}", "bytes=$start-$end")
                try {
                    if (c.responseCode != 206) throw IOException("Bad response ${c.responseCode}")
                    c.inputStream.use { input ->
                        raf.seek(start)
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            raf.write(buf, 0, n)
                            got += n
                            counter.addAndGet(n.toLong())
                        }
                    }
                    if (got != end - start + 1) throw IOException("Short chunk")
                } finally {
                    c.disconnect()
                }
                return
            } catch (e: IOException) {
                counter.addAndGet(-got) // undo partial count before retrying
                if (++attempt >= RETRIES) throw e
            }
        }
    }
}
