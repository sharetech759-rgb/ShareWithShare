/*
 * STEP 6: File picker with tabs (Apps / Photos / Videos / Music + "Files..." for documents).
 * Package: com.example.flashsend.ui
 *
 * AndroidManifest.xml additions (permissions above <application>):
 *   <uses-permission android:name="android.permission.READ_MEDIA_IMAGES"/>
 *   <uses-permission android:name="android.permission.READ_MEDIA_VIDEO"/>
 *   <uses-permission android:name="android.permission.READ_MEDIA_AUDIO"/>
 *   <uses-permission android:name="android.permission.READ_EXTERNAL_STORAGE" android:maxSdkVersion="32"/>
 * And, as a direct child of <manifest> (lets the app list installed apps):
 *   <queries>
 *     <intent>
 *       <action android:name="android.intent.action.MAIN"/>
 *       <category android:name="android.intent.category.LAUNCHER"/>
 *     </intent>
 *   </queries>
 */
package com.example.flashsend.ui

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.util.Size
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import com.example.flashsend.transfer.SharedFile
import com.example.flashsend.transfer.describe
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

data class PickItem(
    val id: String, val name: String, val size: Long, val uri: Uri, val pkg: String? = null
)

enum class Category(val label: String) {
    APPS("Apps"), PHOTOS("Photos"), VIDEOS("Videos"), MUSIC("Music")
}

private fun formatSize(b: Long): String = when {
    b >= 1L shl 30 -> "%.2f GB".format(b / (1024.0 * 1024 * 1024))
    b >= 1L shl 20 -> "%.1f MB".format(b / (1024.0 * 1024))
    b >= 1L shl 10 -> "%.0f KB".format(b / 1024.0)
    else -> "$b B"
}

private fun mediaPerms(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) arrayOf(
        Manifest.permission.READ_MEDIA_IMAGES,
        Manifest.permission.READ_MEDIA_VIDEO,
        Manifest.permission.READ_MEDIA_AUDIO
    ) else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)

private fun hasMediaPerm(ctx: Context) = mediaPerms().any {
    ContextCompat.checkSelfPermission(ctx, it) == PackageManager.PERMISSION_GRANTED
}

private fun loadMedia(ctx: Context, collection: Uri): List<PickItem> {
    val out = ArrayList<PickItem>()
    val projection = arrayOf(
        MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE
    )
    ctx.contentResolver.query(
        collection, projection, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC"
    )?.use { c ->
        while (c.moveToNext() && out.size < 3000) {
            val uri = ContentUris.withAppendedId(collection, c.getLong(0))
            out.add(PickItem(uri.toString(), c.getString(1) ?: "file", c.getLong(2), uri))
        }
    }
    return out
}

/** Shares each app's base APK (split APKs are not included). */
private fun loadApps(ctx: Context): List<PickItem> {
    val pm = ctx.packageManager
    val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
    return pm.queryIntentActivities(intent, 0).mapNotNull { ri ->
        val ai = ri.activityInfo.applicationInfo
        val f = File(ai.sourceDir)
        if (!f.canRead()) null
        else PickItem(
            id = ai.packageName, name = "${ri.loadLabel(pm)}.apk",
            size = f.length(), uri = Uri.fromFile(f), pkg = ai.packageName
        )
    }.distinctBy { it.id }.sortedBy { it.name.lowercase() }
}

private fun load(ctx: Context, c: Category): List<PickItem> = when (c) {
    Category.APPS -> loadApps(ctx)
    Category.PHOTOS -> loadMedia(ctx, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
    Category.VIDEOS -> loadMedia(ctx, MediaStore.Video.Media.EXTERNAL_CONTENT_URI)
    Category.MUSIC -> loadMedia(ctx, MediaStore.Audio.Media.EXTERNAL_CONTENT_URI)
}

@Composable
private fun Thumb(item: PickItem, checked: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val bmp by produceState<ImageBitmap?>(null, item.uri) {
        value = withContext(Dispatchers.IO) {
            runCatching {
                ctx.contentResolver.loadThumbnail(item.uri, Size(240, 240), null).asImageBitmap()
            }.getOrNull()
        }
    }
    Box(Modifier.aspectRatio(1f).padding(2.dp).clickable(onClick = onClick)) {
        val b = bmp
        if (b != null) Image(b, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.surfaceVariant))
        if (checked) Box(
            Modifier.fillMaxSize().background(Color(0x663366FF)),
            contentAlignment = Alignment.TopEnd
        ) {
            Text("✓", color = Color.White, fontWeight = FontWeight.Bold, modifier = Modifier.padding(6.dp))
        }
    }
}

@Composable
private fun ItemRow(item: PickItem, checked: Boolean, onClick: () -> Unit) {
    val ctx = LocalContext.current
    val icon by produceState<ImageBitmap?>(null, item.pkg) {
        value = item.pkg?.let { p ->
            withContext(Dispatchers.IO) {
                runCatching {
                    ctx.packageManager.getApplicationIcon(p).toBitmap(96, 96).asImageBitmap()
                }.getOrNull()
            }
        }
    }
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        icon?.let { Image(it, null, Modifier.size(40.dp)); Spacer(Modifier.width(12.dp)) }
        Column(Modifier.weight(1f)) {
            Text(item.name, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(formatSize(item.size), style = MaterialTheme.typography.bodySmall)
        }
        Checkbox(checked = checked, onCheckedChange = null)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PickerScreen(onDone: (List<SharedFile>) -> Unit, onCancel: () -> Unit) {
    BackHandler(onBack = onCancel)
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    val selected = remember { mutableStateMapOf<String, PickItem>() }
    val loaded = remember { mutableStateMapOf<Category, List<PickItem>>() }
    var mediaGranted by remember { mutableStateOf(hasMediaPerm(ctx)) }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { mediaGranted = hasMediaPerm(ctx) }

    val filesLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenMultipleDocuments()
    ) { uris ->
        uris.forEach { u ->
            val f = describe(ctx, u, 0)
            selected[u.toString()] = PickItem(u.toString(), f.name, f.size, u)
        }
    }

    LaunchedEffect(Unit) { if (!mediaGranted) permLauncher.launch(mediaPerms()) }
    LaunchedEffect(tab, mediaGranted) {
        val c = Category.values()[tab]
        if (loaded[c] == null && (c == Category.APPS || mediaGranted)) {
            loaded[c] = withContext(Dispatchers.IO) { load(ctx, c) }
        }
    }

    fun toggle(item: PickItem) {
        if (selected.containsKey(item.id)) selected.remove(item.id) else selected[item.id] = item
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Select files") },
                navigationIcon = { TextButton(onClick = onCancel) { Text("Cancel") } },
                actions = { TextButton(onClick = { filesLauncher.launch(arrayOf("*/*")) }) { Text("Files…") } }
            )
        },
        bottomBar = {
            Surface(tonalElevation = 3.dp) {
                Button(
                    onClick = {
                        onDone(selected.values.mapIndexed { i, p -> SharedFile(i, p.name, p.size, p.uri) })
                    },
                    enabled = selected.isNotEmpty(),
                    modifier = Modifier.fillMaxWidth().padding(12.dp)
                ) {
                    Text(
                        if (selected.isEmpty()) "Select files to send"
                        else "Send ${selected.size} file(s) · ${formatSize(selected.values.sumOf { it.size })}"
                    )
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad)) {
            ScrollableTabRow(selectedTabIndex = tab, edgePadding = 8.dp) {
                Category.values().forEachIndexed { i, c ->
                    Tab(selected = tab == i, onClick = { tab = i }, text = { Text(c.label) })
                }
            }
            val cat = Category.values()[tab]
            val list = loaded[cat]
            when {
                cat != Category.APPS && !mediaGranted -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Allow access to your media to browse it.")
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { permLauncher.launch(mediaPerms()) }) { Text("Allow") }
                    }
                }
                list == null -> Box(Modifier.fillMaxSize(), Alignment.Center) { CircularProgressIndicator() }
                list.isEmpty() -> Box(Modifier.fillMaxSize(), Alignment.Center) { Text("Nothing here") }
                cat == Category.PHOTOS || cat == Category.VIDEOS ->
                    LazyVerticalGrid(GridCells.Adaptive(96.dp), Modifier.fillMaxSize()) {
                        items(list, key = { it.id }) { item ->
                            Thumb(item, selected.containsKey(item.id)) { toggle(item) }
                        }
                    }
                else -> LazyColumn(Modifier.fillMaxSize()) {
                    items(list, key = { it.id }) { item ->
                        ItemRow(item, selected.containsKey(item.id)) { toggle(item) }
                    }
                }
            }
        }
    }
}
