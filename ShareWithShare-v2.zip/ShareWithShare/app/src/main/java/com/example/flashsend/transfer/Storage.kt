/*
 * STEP 7b: Save received files into the public Downloads/ShareWithShare folder.
 * Package: com.example.flashsend.transfer   (no storage permission needed on API 29+)
 */
package com.example.flashsend.transfer

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import java.io.File

/** Copies [file] into Downloads/ShareWithShare, deletes the private copy, returns true on success. */
fun saveToDownloads(ctx: Context, file: File): Boolean {
    val mime = MimeTypeMap.getSingleton()
        .getMimeTypeFromExtension(file.extension.lowercase()) ?: "application/octet-stream"
    val values = ContentValues().apply {
        put(MediaStore.Downloads.DISPLAY_NAME, file.name)
        put(MediaStore.Downloads.MIME_TYPE, mime)
        put(MediaStore.Downloads.RELATIVE_PATH, "${Environment.DIRECTORY_DOWNLOADS}/ShareWithShare")
        put(MediaStore.Downloads.IS_PENDING, 1)
    }
    val resolver = ctx.contentResolver
    val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
    return try {
        val out = resolver.openOutputStream(uri) ?: throw IllegalStateException("No output stream")
        out.use { o -> file.inputStream().use { it.copyTo(o, 256 * 1024) } }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
        file.delete()
        true
    } catch (e: Exception) {
        resolver.delete(uri, null, null)
        false
    }
}
