/*
 * UPDATED MainActivity.kt (v3: foreground service + saves to Downloads/ShareWithShare).
 * Flow: Send -> pick files -> hotspot + server + QR.
 *       Receive -> scan -> join -> download everything with live speed.
 */
package com.example.flashsend

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.flashsend.connect.HotspotClient
import com.example.flashsend.connect.HotspotHost
import com.example.flashsend.connect.Qr
import com.example.flashsend.transfer.Receiver
import com.example.flashsend.transfer.SenderServer
import com.example.flashsend.transfer.SharedFile
import com.example.flashsend.ui.PickerScreen
import com.example.flashsend.transfer.saveToDownloads
import com.example.flashsend.transfer.localIp
import androidx.compose.foundation.text.selection.SelectionContainer
import com.example.flashsend.service.TransferService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
        )
        setContent { AppTheme { HomeScreen() } }
    }
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Color(0xFF5B9BFF),
            onPrimary = Color.White,
            background = Color(0xFF0B1630),
            onBackground = Color.White,
            surface = Color(0xFF111A33),
            onSurface = Color.White,
            surfaceVariant = Color(0xFF1C2747),
            onSurfaceVariant = Color(0xFFB8C4E0)
        ),
        content = content
    )
}

private const val PORT = 8080

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val host = remember { HotspotHost(ctx) }
    val client = remember { HotspotClient(ctx) }
    var server by remember { mutableStateOf<SenderServer?>(null) }
    var files by remember { mutableStateOf<List<SharedFile>>(emptyList()) }
    var qr by remember { mutableStateOf<Bitmap?>(null) }
    var status by remember { mutableStateOf("Choose Send or Receive") }
    var pcHelp by remember { mutableStateOf<String?>(null) }
    var progress by remember { mutableStateOf<Float?>(null) }
    var pendingAction by remember { mutableStateOf<String?>(null) }

    val perm = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.NEARBY_WIFI_DEVICES else Manifest.permission.ACCESS_FINE_LOCATION

    fun startSend() {
        status = "Starting hotspot..."
        host.start(
            PORT,
            onReady = { info ->
                server?.stop()
                server = SenderServer(ctx, PORT, info.token, files).also {
                    it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                }
                TransferService.start(ctx, "Sharing ${files.size} file(s)")
                pcHelp = "On a PC: join Wi-Fi \"${info.ssid}\" (password: ${info.pass}), " +
                        "then open\nhttp://${localIp()}:$PORT/web?t=${info.token}"
                qr = Qr.render(info.toQrString())
                status = "Sharing ${files.size} file(s). Ask the other phone to scan."
            },
            onError = { status = it }
        )
    }

    fun startReceive() {
        Qr.scan(
            ctx,
            onResult = { info ->
                status = "Joining ${info.ssid}..."
                client.join(
                    info,
                    onConnected = { ip ->
                        scope.launch {
                            try {
                                TransferService.start(ctx, "Receiving...")
                                val rx = Receiver(ctx, ip, info.port, info.token)
                                val list = rx.list()
                                var lastNotify = 0L
                                for ((n, f) in list.withIndex()) {
                                    val saved = rx.download(f) { p ->
                                        val pct = if (p.total > 0) p.done * 100 / p.total else 100
                                        val mbps = p.bytesPerSec / 1_000_000.0
                                        val line = "${p.fileName}  $pct%  ${"%.1f".format(mbps)} MB/s"
                                        status = "(${n + 1}/${list.size}) $line"
                                        progress = if (p.total > 0) (p.done.toFloat() / p.total).coerceIn(0f, 1f) else 1f
                                        val now = System.currentTimeMillis()
                                        if (now - lastNotify > 1000) {
                                            lastNotify = now
                                            TransferService.update(ctx, line)
                                        }
                                    }
                                    status = "Saving ${f.name}..."
                                    withContext(Dispatchers.IO) { saveToDownloads(ctx, saved) }
                                }
                                progress = null
                                status = "Done! ${list.size} file(s) saved in Downloads/ShareWithShare"
                            } catch (e: Exception) {
                                progress = null
                                status = "Transfer failed: ${e.message}"
                            } finally {
                                TransferService.stop(ctx)
                            }
                        }
                    },
                    onError = { status = it }
                )
            },
            onError = { status = it }
        )
    }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) status = "Permission denied"
        else if (pendingAction == "send") startSend() else startReceive()
    }

    // Core permission (Wi-Fi/location) check, then run the action.
    fun proceed(action: String) {
        pendingAction = action
        val ok = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED
        if (!ok) permLauncher.launch(perm)
        else if (action == "send") startSend() else startReceive()
    }

    // Notification permission is optional: continue either way.
    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { proceed(pendingAction ?: "send") }

    fun withPermission(action: String) {
        pendingAction = action
        val needNotif = Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needNotif) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else proceed(action)
    }

    var showPicker by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose { server?.stop(); host.stop(); client.leave(); TransferService.stop(ctx) }
    }

    if (showPicker) {
        PickerScreen(
            onDone = { list -> files = list; showPicker = false; withPermission("send") },
            onCancel = { showPicker = false }
        )
        return
    }

    val bigButtonShape = RoundedCornerShape(18.dp)

    Box(
        Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    listOf(Color(0xFF0B1630), Color(0xFF123A8F), Color(0xFF5B2EDB))
                )
            )
            .safeDrawingPadding()
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(24.dp))
            Box(
                Modifier.size(84.dp).clip(RoundedCornerShape(24.dp)).background(Color(0xFF1E6FEB)),
                contentAlignment = Alignment.Center
            ) {
                Text("SH", color = Color.White, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            }
            Spacer(Modifier.height(16.dp))
            Text("Share with Share", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(
                "Send files to nearby phones and PCs.\nNo internet needed.",
                color = Color(0xFFC7D2F0), fontSize = 14.sp, textAlign = TextAlign.Center
            )
            Spacer(Modifier.height(32.dp))

            Column(
                Modifier.widthIn(max = 480.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Button(
                    onClick = { showPicker = true },
                    modifier = Modifier.fillMaxWidth().height(60.dp),
                    shape = bigButtonShape,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color.White, contentColor = Color(0xFF123A8F)
                    )
                ) { Text("Send", fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }

                OutlinedButton(
                    onClick = { withPermission("receive") },
                    modifier = Modifier.fillMaxWidth().height(60.dp),
                    shape = bigButtonShape,
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = BorderStroke(1.5.dp, Color.White.copy(alpha = 0.7f))
                ) { Text("Receive", fontSize = 18.sp, fontWeight = FontWeight.SemiBold) }
            }

            Spacer(Modifier.height(24.dp))
            Surface(
                modifier = Modifier.widthIn(max = 480.dp).fillMaxWidth(),
                shape = RoundedCornerShape(20.dp),
                color = Color.White.copy(alpha = 0.12f)
            ) {
                Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(status, color = Color.White, fontSize = 15.sp, textAlign = TextAlign.Center)
                    progress?.let { frac ->
                        Spacer(Modifier.height(12.dp))
                        LinearProgressIndicator(
                            progress = { frac },
                            modifier = Modifier.fillMaxWidth().height(8.dp).clip(CircleShape),
                            color = Color.White,
                            trackColor = Color.White.copy(alpha = 0.25f)
                        )
                    }
                }
            }

            AnimatedVisibility(visible = qr != null) {
                qr?.let { bmp ->
                    val img = remember(bmp) { bmp.asImageBitmap() }
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Spacer(Modifier.height(20.dp))
                        Box(
                            Modifier
                                .widthIn(max = 320.dp)
                                .fillMaxWidth(0.8f)
                                .aspectRatio(1f)
                                .clip(RoundedCornerShape(24.dp))
                                .background(Color.White)
                                .padding(14.dp)
                        ) {
                            Image(img, contentDescription = "Connection QR code", modifier = Modifier.fillMaxSize())
                        }
                    }
                }
            }

            pcHelp?.let {
                Spacer(Modifier.height(16.dp))
                Surface(
                    modifier = Modifier.widthIn(max = 480.dp).fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    color = Color.White.copy(alpha = 0.08f)
                ) {
                    SelectionContainer {
                        Text(it, color = Color(0xFFC7D2F0), fontSize = 12.sp, modifier = Modifier.padding(14.dp))
                    }
                }
            }

            if (server != null) {
                Spacer(Modifier.height(16.dp))
                OutlinedButton(
                    onClick = {
                        server?.stop(); server = null; host.stop(); qr = null; pcHelp = null
                        TransferService.stop(ctx)
                        status = "Sharing stopped"
                    },
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = Color.White),
                    border = BorderStroke(1.dp, Color.White.copy(alpha = 0.6f))
                ) { Text("Stop sharing") }
            }
            Spacer(Modifier.height(24.dp))
        }
    }
}
