/*
 * STEP 3: Connection layer (hotspot + QR). Package: com.example.flashsend.connect
 *
 * build.gradle (app) dependencies:
 *   implementation("com.google.zxing:core:3.5.3")
 *   implementation("com.google.android.gms:play-services-code-scanner:16.1.0")
 *
 * AndroidManifest.xml permissions:
 *   <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
 *   <uses-permission android:name="android.permission.CHANGE_WIFI_STATE"/>
 *   <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE"/>
 *   <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="32"/>
 *   <uses-permission android:name="android.permission.NEARBY_WIFI_DEVICES"
 *       android:usesPermissionFlags="neverForLocation"/>
 *
 * Runtime permission to request before HotspotHost.start():
 *   Android 13+ : NEARBY_WIFI_DEVICES
 *   Android 8-12: ACCESS_FINE_LOCATION (and Location must be switched ON)
 */
package com.example.flashsend.connect

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.net.*
import android.net.wifi.WifiManager
import android.net.wifi.WifiNetworkSpecifier
import android.os.Build
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter
import java.net.URLEncoder
import java.security.SecureRandom

/** Everything the receiver needs, packed into the QR code. */
data class ConnectInfo(val ssid: String, val pass: String, val port: Int, val token: String) {

    fun toQrString(): String =
        "flashsend://connect?ssid=${enc(ssid)}&pass=${enc(pass)}&port=$port&token=${enc(token)}"

    companion object {
        private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

        fun newToken(): String =
            ByteArray(16).also { SecureRandom().nextBytes(it) }.joinToString("") { "%02x".format(it) }

        fun parse(raw: String?): ConnectInfo? {
            if (raw == null) return null
            val u = Uri.parse(raw)
            if (u.scheme != "flashsend") return null
            return ConnectInfo(
                ssid = u.getQueryParameter("ssid") ?: return null,
                pass = u.getQueryParameter("pass") ?: return null,
                port = u.getQueryParameter("port")?.toIntOrNull() ?: return null,
                token = u.getQueryParameter("token") ?: return null
            )
        }
    }
}

/** SENDER side: starts a local-only hotspot (no internet needed, no user toggling). */
class HotspotHost(context: Context) {
    private val wifi = context.applicationContext
        .getSystemService(Context.WIFI_SERVICE) as WifiManager
    private var reservation: WifiManager.LocalOnlyHotspotReservation? = null

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    fun start(port: Int, onReady: (ConnectInfo) -> Unit, onError: (String) -> Unit) {
        try {
            wifi.startLocalOnlyHotspot(object : WifiManager.LocalOnlyHotspotCallback() {
                override fun onStarted(r: WifiManager.LocalOnlyHotspotReservation) {
                    reservation = r
                    val ssid: String?
                    val pass: String?
                    if (Build.VERSION.SDK_INT >= 30) {
                        val c = r.softApConfiguration
                        ssid = if (Build.VERSION.SDK_INT >= 33)
                            c.wifiSsid?.toString()?.trim('"') else c.ssid
                        pass = c.passphrase
                    } else {
                        val c = r.wifiConfiguration
                        ssid = c?.SSID?.trim('"')
                        pass = c?.preSharedKey?.trim('"')
                    }
                    if (ssid == null || pass == null) {
                        onError("Could not read hotspot credentials"); return
                    }
                    onReady(ConnectInfo(ssid, pass, port, ConnectInfo.newToken()))
                }

                override fun onStopped() { reservation = null }

                override fun onFailed(reason: Int) {
                    onError("Hotspot failed (code $reason). Is Location ON and permission granted?")
                }
            }, null)
        } catch (e: SecurityException) {
            onError("Missing permission: ${e.message}")
        }
    }

    fun stop() { reservation?.close(); reservation = null }
}

/** RECEIVER side: joins the sender's hotspot without leaving the app. */
class HotspotClient(context: Context) {
    private val cm = context.applicationContext
        .getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private var callback: ConnectivityManager.NetworkCallback? = null

    /** onConnected gives the sender's IP address. Requires Android 10+ (API 29). */
    fun join(info: ConnectInfo, onConnected: (host: String) -> Unit, onError: (String) -> Unit) {
        val specifier = WifiNetworkSpecifier.Builder()
            .setSsid(info.ssid)
            .setWpa2Passphrase(info.pass)
            .build()
        val request = NetworkRequest.Builder()
            .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
            .removeCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .setNetworkSpecifier(specifier)
            .build()

        var done = false
        callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                // Route this app's traffic through the hotspot.
                cm.bindProcessToNetwork(network)
            }

            override fun onLinkPropertiesChanged(network: Network, lp: LinkProperties) {
                if (done) return
                val gateway = lp.routes.firstOrNull { it.gateway != null && !it.gateway!!.isAnyLocalAddress }
                    ?.gateway?.hostAddress
                if (gateway != null) {
                    done = true
                    onConnected(gateway)
                }
            }

            override fun onUnavailable() { onError("Could not join the sender's Wi-Fi") }
            override fun onLost(network: Network) { cm.bindProcessToNetwork(null) }
        }
        try {
            cm.requestNetwork(request, callback!!, 30_000)
        } catch (e: Exception) {
            onError("Could not join Wi-Fi: ${e.message}")
        }
    }

    fun leave() {
        callback?.let { runCatching { cm.unregisterNetworkCallback(it) } }
        cm.bindProcessToNetwork(null)
        callback = null
    }
}

object Qr {
    /** Render text as a QR bitmap for display on the sender's screen. */
    fun render(text: String, size: Int = 768): Bitmap {
        val m = QRCodeWriter().encode(text, BarcodeFormat.QR_CODE, size, size)
        val bmp = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
        for (x in 0 until size) for (y in 0 until size)
            bmp.setPixel(x, y, if (m[x, y]) Color.BLACK else Color.WHITE)
        return bmp
    }

    /** Google's code scanner UI: no camera permission needed. */
    fun scan(context: Context, onResult: (ConnectInfo) -> Unit, onError: (String) -> Unit) {
        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .build()
        GmsBarcodeScanning.getClient(context, options).startScan()
            .addOnSuccessListener { b ->
                ConnectInfo.parse(b.rawValue)?.let(onResult) ?: onError("Not a Share with Share QR code")
            }
            .addOnFailureListener { onError(it.message ?: "Scan cancelled") }
    }
}
