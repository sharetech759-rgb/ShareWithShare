/*
 * UPDATED MainActivity.kt (v3: foreground service + saves to Downloads/ShareWithShare).
 * Flow: Send -> pick files -> hotspot + server + QR.
 *       Receive -> scan -> join -> download everything with live speed.
 */
package com.example.flashsend

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.example.flashsend.connect.HotspotClient
import com.example.flashsend.connect.HotspotHost
import com.example.flashsend.connect.Qr
import com.example.flashsend.transfer.Receiver
import com.example.flashsend.transfer.SenderServer
import com.example.flashsend.transfer.SharedFile
import com.example.flashsend.ui.PickerScreen
import com.example.flashsend.transfer.saveToDownloads
import com.example.flashsend.transfer.localIp
import androidx.compose.foundation.text.selection.SelectionContainer
import com.example.flashsend.service.TransferService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import fi.iki.elonen.NanoHTTPD
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { HomeScreen() } } }
    }
}

private const val PORT = 8080

@Composable
fun HomeScreen() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val host = remember { HotspotHost(ctx) }
    val client = remember { HotspotClient(ctx) }
    var server by remember { mutableStateOf<SenderServer?>(null) }
    var files by remember { mutableStateOf<List<SharedFile>>(emptyList()) }
    var qr by remember { mutableStateOf<Bitmap?>(null) }
    var status by remember { mutableStateOf("Choose Send or Receive") }
    var pcHelp by remember { mutableStateOf<String?>(null) }
    var pendingAction by remember { mutableStateOf<String?>(null) }

    val perm = if (Build.VERSION.SDK_INT >= 33)
        Manifest.permission.NEARBY_WIFI_DEVICES else Manifest.permission.ACCESS_FINE_LOCATION

    fun startSend() {
        status = "Starting hotspot..."
        host.start(
            PORT,
            onReady = { info ->
                server?.stop()
                server = SenderServer(ctx, PORT, info.token, files).also {
                    it.start(NanoHTTPD.SOCKET_READ_TIMEOUT, false)
                }
                TransferService.start(ctx, "Sharing ${files.size} file(s)")
                pcHelp = "On a PC: join Wi-Fi \"${info.ssid}\" (password: ${info.pass}), " +
                        "then open\nhttp://${localIp()}:$PORT/web?t=${info.token}"
                qr = Qr.render(info.toQrString())
                status = "Sharing ${files.size} file(s). Ask the other phone to scan."
            },
            onError = { status = it }
        )
    }

    fun startReceive() {
        Qr.scan(
            ctx,
            onResult = { info ->
                status = "Joining ${info.ssid}..."
                client.join(
                    info,
                    onConnected = { ip ->
                        scope.launch {
                            try {
                                TransferService.start(ctx, "Receiving...")
                                val rx = Receiver(ctx, ip, info.port, info.token)
                                val list = rx.list()
                                var lastNotify = 0L
                                for ((n, f) in list.withIndex()) {
                                    val saved = rx.download(f) { p ->
                                        val pct = if (p.total > 0) p.done * 100 / p.total else 100
                                        val mbps = p.bytesPerSec / 1_000_000.0
                                        val line = "${p.fileName}  $pct%  ${"%.1f".format(mbps)} MB/s"
                                        status = "(${n + 1}/${list.size}) $line"
                                        val now = System.currentTimeMillis()
                                        if (now - lastNotify > 1000) {
                                            lastNotify = now
                                            TransferService.update(ctx, line)
                                        }
                                    }
                                    status = "Saving ${f.name}..."
                                    withContext(Dispatchers.IO) { saveToDownloads(ctx, saved) }
                                }
                                status = "Done! ${list.size} file(s) saved in Downloads/ShareWithShare"
                            } catch (e: Exception) {
                                status = "Transfer failed: ${e.message}"
                            } finally {
                                TransferService.stop(ctx)
                            }
                        }
                    },
                    onError = { status = it }
                )
            },
            onError = { status = it }
        )
    }

    val permLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (!granted) status = "Permission denied"
        else if (pendingAction == "send") startSend() else startReceive()
    }

    // Core permission (Wi-Fi/location) check, then run the action.
    fun proceed(action: String) {
        pendingAction = action
        val ok = ContextCompat.checkSelfPermission(ctx, perm) == PackageManager.PERMISSION_GRANTED
        if (!ok) permLauncher.launch(perm)
        else if (action == "send") startSend() else startReceive()
    }

    // Notification permission is optional: continue either way.
    val notifLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { proceed(pendingAction ?: "send") }

    fun withPermission(action: String) {
        pendingAction = action
        val needNotif = Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(
            ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needNotif) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else proceed(action)
    }

    var showPicker by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        onDispose { server?.stop(); host.stop(); client.leave(); TransferService.stop(ctx) }
    }

    if (showPicker) {
        PickerScreen(
            onDone = { list -> files = list; showPicker = false; withPermission("send") },
            onCancel = { showPicker = false }
        )
        return
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Share with Share", style = MaterialTheme.typography.headlineLarge)
        Spacer(Modifier.height(24.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
            Button(onClick = { showPicker = true }) { Text("Send") }
            Button(onClick = { withPermission("receive") }) { Text("Receive") }
        }
        Spacer(Modifier.height(24.dp))
        qr?.let {
            Image(it.asImageBitmap(), contentDescription = "Connection QR code",
                modifier = Modifier.size(280.dp))
            Spacer(Modifier.height(16.dp))
        }
        Text(status)
        pcHelp?.let {
            Spacer(Modifier.height(12.dp))
            SelectionContainer { Text(it, style = MaterialTheme.typography.bodySmall) }
        }
        if (server != null) {
            Spacer(Modifier.height(16.dp))
            OutlinedButton(onClick = {
                server?.stop(); server = null; host.stop(); qr = null; pcHelp = null
                TransferService.stop(ctx)
                status = "Sharing stopped"
            }) { Text("Stop sharing") }
        }
    }
}
